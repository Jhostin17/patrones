import Modelo.Cuento;
import Modelo.FactoryFantasia;
import Modelo.FactoryTerror;
import Modelo.abstractFactory;
import Modelo.cuentoTerror;
import Modelo.factoryFiccion;

public class Cliente {
	public static void main(String[] args) {
		
		abstractFactory Factory = null;
		///
		
		Factory = new factoryFiccion();
		
		
		
		///
		Cuento c = Factory.getTipo();
		System.out.println(c.getContenido());
		
		
		
		
	}
}
