package Modelo;

public class FactoryTerror implements abstractFactory{

	@Override
	public Cuento getTipo() {
		return new cuentoTerror();
	}

}
