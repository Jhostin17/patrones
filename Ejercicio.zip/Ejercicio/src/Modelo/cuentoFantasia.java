package Modelo;

public class cuentoFantasia implements Cuento{

	@Override
	public String getContenido() {
		// TODO Auto-generated method stub
		return "Contenido Fantasioso";
	}

}
