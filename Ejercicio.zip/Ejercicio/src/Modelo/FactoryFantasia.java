package Modelo;

public class FactoryFantasia implements abstractFactory{

	@Override
	public Cuento getTipo() {
		// TODO Auto-generated method stub
		return new cuentoFantasia();
	}

}
