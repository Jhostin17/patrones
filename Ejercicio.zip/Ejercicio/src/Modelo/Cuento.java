package Modelo;

public interface Cuento {
	public String getContenido();
}
