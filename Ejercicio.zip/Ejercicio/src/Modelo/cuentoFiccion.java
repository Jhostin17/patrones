package Modelo;

public class cuentoFiccion implements Cuento{

	@Override
	public String getContenido() {
		// TODO Auto-generated method stub
		return "Contenido de Ficcion";
	}

}
