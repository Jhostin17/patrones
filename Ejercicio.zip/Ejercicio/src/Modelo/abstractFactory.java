package Modelo;

public interface abstractFactory {
	public Cuento getTipo();
}
