package Modelo;

public class factoryFiccion implements abstractFactory {

	@Override
	public Cuento getTipo() {
		// TODO Auto-generated method stub
		return new cuentoFiccion();
	}
	
}
