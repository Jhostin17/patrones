package Modelo;

public class cuentoTerror implements Cuento{

	@Override
	public String getContenido() {
		// TODO Auto-generated method stub
		return "Contenido de Terror";
	}

}
