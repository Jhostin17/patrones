package vista;

import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;

import model.Persona;

public class Panel extends JPanel {

    public Panel() {
        // Establece el layout del panel
        setLayout(null);
    }

    // Método setter para establecer las personas
    public void setPersonas(ArrayList<Persona> personas) {
        // Remueve todos los componentes existentes para evitar duplicados
        removeAll();
        
        // Itera sobre el ArrayList de personas y añade un JLabel para cada uno
        for (Persona persona : personas) {
            JLabel personaLabel = new JLabel(persona.toString());
            add(personaLabel);
        }
        
        // Esto asegura que el panel se actualice correctamente después de añadir los nuevos componentes
        revalidate();
        repaint();
    }
}
